package cn.com.bjnews.thinker.act.test;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.HorizontalScrollView;
/**
 * 
 * @author sunqm
 * @version 创建时间：2014-8-7 上午10:34:14
 * TODO  主要处理滑动的监听，以及相关操作
 */
public class NavigateHorizonScrollView extends HorizontalScrollView{

	public NavigateHorizonScrollView(Context context, AttributeSet attrs) {
		super(context, attrs);
		
	}

}
