package cn.com.bjnews.thinker.act.test.internet;

public class InternetTools {

}
