package cn.com.bjnews.thinker.entity;
/**
 * 广告实体类
 * @author sunqm
 * Create at:   2014-5-16 下午2:46:11 
 * TODO
 */
public class AdIntroEntity {
	
	
	public String id;

	public String picUrl;
	
	public String url;
	/**描述*/
	public String caption;
	
}
