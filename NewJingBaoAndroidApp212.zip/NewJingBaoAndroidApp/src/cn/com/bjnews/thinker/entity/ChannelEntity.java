package cn.com.bjnews.thinker.entity;

/**
 * 
 * @author sunqm
 * Create at:   2014-5-16 上午8:35:53 
 * TODO 标题种类
 */
public class ChannelEntity {

	public int id;
	
	public String name;
	
	public String url;
	
}
