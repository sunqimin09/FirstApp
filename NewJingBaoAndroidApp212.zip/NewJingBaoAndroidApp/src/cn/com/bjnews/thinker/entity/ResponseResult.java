package cn.com.bjnews.thinker.entity;

/**
 * 返回的 结果实体类
 * @author sunqm
 * Create at:   2014-5-13 上午7:32:35 
 * TODO
 */
public class ResponseResult {
	
	/**请求码*/
	public int requestCode;
	
	public int resultCode;
	
	public String resultStr;
	
	
	
}
