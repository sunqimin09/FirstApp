package cn.com.bjnews.thinker.entity;
/**
 * 要闻 实体类
 * @author sunqm
 * Create at:   2014-5-12 下午7:40:16 
 * TODO
 */

public class YaoWenEntity {
	
	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getContent() {
		return content;
	}


	public void setContent(String content) {
		this.content = content;
	}


	private String id = "00";
	
	
	private String content;
	
	
	
}
