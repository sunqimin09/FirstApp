package cn.com.bjnews.thinker.img;

public class ImageScale {
	
}
